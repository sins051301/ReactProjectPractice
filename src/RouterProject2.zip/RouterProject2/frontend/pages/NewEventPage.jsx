import EventForm from "../src/components/EventForm";
function NewEventPage() {
  return <EventForm method={"POST"}></EventForm>;
}
export default NewEventPage;
